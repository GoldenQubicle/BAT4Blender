import bpy
from .Camera import CAM_NAME
from .Sun import SUN_NAME
from .LOD import LOD_NAME


class Rig:
    @staticmethod
    def preview():
        if CAM_NAME not in bpy.data.objects \
                or SUN_NAME not in bpy.data.objects\
                or LOD_NAME not in bpy.data.objects:
                print("yooo")
