LOD_NAME = "b4b_lod"
SUN_NAME = "b4b_sun"
CAM_NAME = "b4b_cam"
