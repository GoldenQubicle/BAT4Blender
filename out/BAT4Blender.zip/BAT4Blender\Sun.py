import bpy


def test():
    print("yep")
